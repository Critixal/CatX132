
local Library = loadstring(game:HttpGet("https://raw.githubusercontent.com/xHeptc/Kavo-UI-Library/main/source.lua"))()
local Window = Library.CreateLib("CatX Hub", "Serpent")

local Main = Window:NewTab("Admin")
local Section1 = Main:NewSection("Admin Scripts")

local Cred = Window:NewTab("Credits")
local Cred1 = Cred:NewSection("Ginny")
local Cred1 = Cred:NewSection("And crxzys")

Section1:NewButton("Infinite Yield", "Universal Admin script", function()
    print("Clicked")
end)

Section1:NewButton("CMD X", "Universal Admin script", function()
    loadstring(game:HttpGet('https://pastebin.com/raw/dBDCw7hw'))()
end)



local Section2 = Window:NewTab("Character Editor")
local Section2 = Section2:NewSection("Character Editor")
Section2:NewSlider("Walk speed", "Changes player walkspeed", 500, 0, function(s) -- 500 (MaxValue) | 0 (MinValue)
    game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = s
end)

Section2:NewSlider("Jump Power", "Changes player JumpPower", 500, 0, function(s) -- 500 (MaxValue) | 0 (MinValue)
    game.Players.LocalPlayer.Character.Humanoid.JumpPower = s
end)


Section1:NewKeybind("F to toggle UI", "Toggles UI", Enum.KeyCode.F, function()
	Library:ToggleUI()
end)


local skywar = Window:NewTab("Skywars")
local skywar = skywar:NewSection("Skywars scripts")
skywar:NewButton("OP Hub", "idk just can do combat scripts", function()
    loadstring(game:HttpGet('https://pastebin.com/raw/CTBHtCd7'))()
end)

local jail = Window:NewTab("JailBreak")
local jail = jail:NewSection("JailBreak Hubs")
jail:NewButton("MonkeyHub","Multi Purpose Jailbreak Script", function()
   loadstring(game:HttpGet('https://pastebin.com/raw/xNGr7TRY'))()
end)

local dh = Window:NewTab("Arsenal")
local dh = dh:NewSection("DarkHub")
dh:NewButton("Dark Hub","Overpowered dark hub script", function()
   loadstring(game:HttpGet('https://pastebin.com/raw/xNGr7TRY'))()
end)

local ass = Window:NewTab("Breaking Point")
local ass = ass:NewSection("Outlaws Hub")
ass:NewButton("Outlaws Hub","Overpowerd breaking point script", function()
    loadstring(game:HttpGet('https://raw.githubusercontent.com/MostafaXc00dy/MostafaXc00dy/main/OutlawsHub/Free/V6.lua'))()
end)	


local Server = Window:NewTab("Chat Bypassers")
local Server = Server:NewSection("Bypasses")
Server:NewButton("Chat Bypasser","Bypasses chat filter", function()
    loadstring(game:HttpGet('https://pastebin.com/raw/ZDgscg3v'))()
end)
