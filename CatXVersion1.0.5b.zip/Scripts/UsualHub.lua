-- Games
-- BigPaintBall - https://www.roblox.com/games/3527629287/BIG-Paintball
-- Nen Fighting Sim - https://www.roblox.com/games/9555732501/Nen-Fighting-Simulator-MOBILE
-- Arsenal - https://www.roblox.com/games/286090429/Arsenal

loadstring(game:HttpGet("https://raw.githubusercontent.com/UsualCodeMan/Usual-hub/main/Loader/Loader.lua"))()